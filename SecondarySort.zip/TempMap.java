package SecondarySortCorrect;

import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.NullWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

import java.io.IOException;

/**
 * 二次排序:
 *  使用自定Key作为KeyOut
 */
public class TempMap extends Mapper<LongWritable,Text, ComboKey,NullWritable> {


    @Override
    protected void map(LongWritable key, Text value, Context context) throws IOException, InterruptedException {
        String line = value.toString();
        String[] arr = line.split(" ");
        // 将年份和温度组合成了一个Key,用来作为map的输出.
        ComboKey comboKey = new ComboKey();
        // year
        comboKey.setYear(Integer.parseInt(arr[0]));
        // temp
        comboKey.setTemp(Integer.parseInt(arr[1]));

        // NullWritable : 调用get方法获取单例的NullWriable对象.
        context.write(comboKey,NullWritable.get());
    }
}
