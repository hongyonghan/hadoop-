package SecondarySortCorrect;

import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.NullWritable;
import org.apache.hadoop.mapreduce.Reducer;

import java.io.IOException;

/**
 * Created by mac on 19/12/6.
 */
public class TempReduce extends Reducer<ComboKey,NullWritable,IntWritable,IntWritable> {


    @Override
    protected void reduce(ComboKey key, Iterable<NullWritable> values, Context context) throws IOException, InterruptedException {
        int year = key.getYear();
        int temp = key.getTemp();
        /*
        for(NullWritable n : values) {
            System.out.println("year=" + year + ";temp=" + temp);
        }
        */
        context.write(new IntWritable(year),new IntWritable(temp));
    }
}
