package SecondarySortCorrect;


import org.apache.hadoop.io.WritableComparable;
import org.apache.hadoop.io.WritableComparator;

/**
 *  排序器:
 *      实现WritableComparator
 *      重写Comparato中的compare方法:
 */
public class TempComparator extends WritableComparator {

    protected TempComparator() {
        super(ComboKey.class,true);
    }

    public int compare(WritableComparable wc1, WritableComparable wc2){
        ComboKey k1 = (ComboKey) wc1 ;
        ComboKey k2 = (ComboKey) wc2 ;
        return k1.compareTo(k2);
    }
}
