package SecondarySortCorrect;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.NullWritable;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.input.TextInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;

/**
 * Created by mac on 19/12/6.
 */
public class TempApp {

    public static void main(String[] args) throws Exception{
        Configuration conf = new Configuration();
        Job job = Job.getInstance(conf);

        // 任务名
        job.setJobName("secondary sort");

        // 设置数据输入格式
        job.setInputFormatClass(TextInputFormat.class);

        //设置map和reduce
        job.setMapperClass(TempMap.class);
        job.setReducerClass(TempReduce.class);

        // 设置map的输出
        job.setMapOutputKeyClass(ComboKey.class);
        job.setMapOutputValueClass(NullWritable.class);

        // 设置reduce的输出
        job.setOutputKeyClass(IntWritable.class);
        job.setOutputValueClass(IntWritable.class);

        // 设置输入路径
        Path in = new Path("G:\\1File\\Test1.txt");
        FileInputFormat.addInputPath(job,in);
        /* 数值输出路径 */
        Path out = new Path("G:\\1File\\out8");
        FileOutputFormat.setOutputPath(job,out);

        // 设置自定义分区类
        job.setPartitionerClass(YearPartitioner.class);
        // 设置自定义分组类
        job.setGroupingComparatorClass(ComboKeyGroupComparator.class);
        // 设置自定义排序类
        job.setSortComparatorClass(TempComparator.class);
        // reduce个数
        job.setNumReduceTasks(3);

        // 启动任务
        job.waitForCompletion(true);
    }
}
