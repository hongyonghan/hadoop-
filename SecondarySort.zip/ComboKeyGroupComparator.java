package SecondarySortCorrect;

import org.apache.hadoop.io.WritableComparable;
import org.apache.hadoop.io.WritableComparator;

/**
 * Created by mac on 19/12/6.
 */
public class ComboKeyGroupComparator extends WritableComparator {

    protected ComboKeyGroupComparator() {
        super(ComboKey.class,true);
    }

    @Override
    public int compare(WritableComparable a, WritableComparable b) {
        ComboKey k1 = (ComboKey)a ;
        ComboKey k2 = (ComboKey)b ;
        return k1.getYear() - k2.getYear();
        //return k1.compareTo(k2); //获得每一年的所有温度的排序
    }
}
