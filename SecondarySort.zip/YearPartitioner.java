package SecondarySortCorrect;

import org.apache.hadoop.io.NullWritable;
import org.apache.hadoop.mapreduce.Partitioner;


/**
 * Created by mac on 19/12/6.
 */
class YearPartitioner extends Partitioner<ComboKey,NullWritable> {

    /**
     * 自定义分区:
     *      根据numPartition(reduceNum)进行取模分区 ->常用分区手段.
     */
    public int getPartition(ComboKey key, NullWritable value, int numPartitions) {
        int year = key.getYear(); //获取年份
        return year % numPartitions;
    }
}
